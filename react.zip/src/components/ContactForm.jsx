export const ContactForm = () => {
    return (
        <form>
            <input type="text" placeholder="Name" />
            <br />
            <input type="email" placeholder="Email" />
        </form>
    )
}