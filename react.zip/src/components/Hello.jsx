export const Hello = () => {
    return (
        <div id="container">
            <h1>Hello React!</h1>
        </div>
    )
}