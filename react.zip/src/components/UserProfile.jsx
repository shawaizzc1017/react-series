export const UserProfile = () => {
    return (
        <>
            <h1>React Course</h1>
            <p>Author: me</p>
        </>
    )
}